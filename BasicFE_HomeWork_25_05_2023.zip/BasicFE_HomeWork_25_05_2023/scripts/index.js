/*
Home Work 25_05_2023

 1 уровень сложности: Цикл while:


Вывод таблицы умножения для определенного числа в массив, 
каждый элемент массива в виде: число * итератор = результат.
 Для формирования строки используйте интерполяцию.


Поиск первого положительного числа в массиве: есть массив 
чисел и нужно найти первое число, которое является положительным.


Генерация случайного пароля: есть некая константа, которая 
отвечает за длину пароля. Сгенерируйте рандомный пароль до 
указанной длины, используя Math.random:





for:



Объединение элементов массива в строку при помощи конкатенации: есть
 массив строк (например, список покупок) - необходимо вывести его в виде строки.


Поиск наибольшего числа в массиве


Переворот строки: есть некая константа, содержащая строку.
 Необходимо вывести строку наоборот, используя цикл for


Подсчет количества гласных букв в строке: есть строка и массив 
гласных в алфавите (можно выбрать английский). Необходимо посчитать,
 сколько раз встречаются гласные в этой строке. Методы для решения 
 этой задачи Вы найдете в файлике к уроку.



Функции



Напишите функцию, которая принимает массив чисел и возвращает их сумму.


Напишите функцию findMax, которая принимает массив чисел и 
возвращает максимальное число из этого массива.


Напишите функцию reverseArray, которая принимает массив и возвращает 
новый массив, в котором элементы идут в обратном порядке.


Напишите функцию, которая принимает массив строк и возвращает новый
 массив, содержащий только строки, начинающиеся с заданной буквы.


Напишите функцию, которая принимает число и возвращает его факториал.


Напишите функцию, которая принимает число и возвращает "Fizz", если число
 делится на 3, "Buzz", если число делится на 5, и "FizzBuzz", если число 
 делится и на 3, и на 5. В остальных случаях вернуть само число.


Создайте функциональное выражение calculateCircleArea, которое принимает 
объект circle с свойством radius и возвращает площадь круга.


Создайте функциональное выражение calculateAverageGrade, которое
 принимает объект student с массивом оценок grades и возвращает среднюю оценку
  студента (попробуйте использовать reduce, описанный в файле предыдущего урока).


Создайте функциональное выражение getFullName, которое принимает объект person
 с свойствами firstName и lastName и возвращает полное имя.


Создайте объект calculator с двумя свойствами operand1 и operand2, и двумя
 методами: add и multiply. Метод add должен принимать два числа и возвращать 
 их сумму, а метод multiply должен принимать два числа и возвращать их произведение.



*/

//1.Вывод таблицы умножения для определенного числа в массив:
function multiplicationTable(number) {
  let table = [];
  let i = 1;

  while (i <= 10) {
    let result = number * i;
    table.push(`${number} * ${i} = ${result}`);
    i++;
  }

  return table;
}

const multiplicationResult = multiplicationTable(5);
console.log(multiplicationResult);

//Поиск первого положительного числа в массиве:
function findFirstPositiveNumber(numbers) {
  let i = 0;

  while (i < numbers.length) {
    if (numbers[i] > 0) {
      return numbers[i];
    }
    i++;
  }

  return "В массиве нет положительных чисел.";
}

const numbersArray = [-2, 0, 5, -1, 10];
const firstPositive = findFirstPositiveNumber(numbersArray);
console.log(firstPositive);

//Генерация случайного пароля:

function generateRandomPassword(length) {
  const charset =
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let password = "";

  while (password.length < length) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    password += charset[randomIndex];
  }

  return password;
}

const randomPassword = generateRandomPassword(8); // Указать желаемую длину пароля
console.log(randomPassword);

//Объединение элементов массива в строку при помощи конкатенации:
function concatenateArrayToString(array) {
  let resultString = "";

  for (let i = 0; i < array.length; i++) {
    resultString += array[i];
    if (i < array.length - 1) {
      resultString += ", "; // Добавляем запятую после каждого элемента, кроме последнего
    }
  }

  return resultString;
}

const shoppingList = ["Яблоко", "Молоко", "Хлеб"];
const shoppingString = concatenateArrayToString(shoppingList);
console.log(shoppingString);

//Поиск наибольшего числа в массиве:
function findMaxNumber(numbers) {
  let maxNumber = numbers[0];

  for (let i = 1; i < numbers.length; i++) {
    if (numbers[i] > maxNumber) {
      maxNumber = numbers[i];
    }
  }

  return maxNumber;
}

const numbersArray = [7, 2, 10, 5, 8];
const maxNumber = findMaxNumber(numbersArray);
console.log("Наибольшее число: " + maxNumber);

//Переворот строки:
function reverseString(inputString) {
  let reversedString = "";

  for (let i = inputString.length - 1; i >= 0; i--) {
    reversedString += inputString[i];
  }

  return reversedString;
}

const originalString = "JavaScript";
const reversed = reverseString(originalString);
console.log("Перевернутая строка: " + reversed);

//Подсчет количества гласных букв в строке:
function countVowels(inputString) {
  const vowels = ["a", "e", "i", "o", "u"];
  let count = 0;

  for (let i = 0; i < inputString.length; i++) {
    if (vowels.includes(inputString[i].toLowerCase())) {
      count++;
    }
  }

  return count;
}

const testString = "Hello World";
const vowelsCount = countVowels(testString);
console.log("Количество гласных букв: " + vowelsCount);

//Функции

//Сумма чисел в массиве:
function sumArray(numbers) {
  return numbers.reduce((acc, curr) => acc + curr, 0);
}

const numbersArray = [1, 2, 3, 4, 5];
console.log("Сумма чисел: " + sumArray(numbersArray));

//Поиск максимального числа:
function findMax(numbers) {
  return Math.max(...numbers);
}

const numbersArray2 = [10, 5, 8, 15, 2];
console.log("Максимальное число: " + findMax(numbersArray2));

//Реверс массива:
function reverseArray(arr) {
  return arr.slice().reverse();
}

const originalArray = [1, 2, 3, 4, 5];
console.log("Реверс массива: " + reverseArray(originalArray));

//Фильтрация строк по начальной букве:
function filterByFirstLetter(arr, letter) {
  return arr.filter((str) => str.startsWith(letter));
}

const stringsArray = ["apple", "banana", "orange", "kiwi"];
const filteredStrings = filterByFirstLetter(stringsArray, "b");
console.log("Строки, начинающиеся с 'b': " + filteredStrings);

//Факториал числа:
function factorial(n) {
  if (n === 0 || n === 1) {
    return 1;
  }
  return n * factorial(n - 1);
}

const num = 5;
console.log("Факториал числа " + num + ": " + factorial(num));

//FizzBuzz:
function fizzBuzz(num) {
  if (num % 3 === 0 && num % 5 === 0) {
    return "FizzBuzz";
  } else if (num % 3 === 0) {
    return "Fizz";
  } else if (num % 5 === 0) {
    return "Buzz";
  } else {
    return num;
  }
}

console.log(fizzBuzz(15));

//Площадь круга:
const calculateCircleArea = (circle) => Math.PI * Math.pow(circle.radius, 2);

const circle = { radius: 5 };
console.log("Площадь круга: " + calculateCircleArea(circle));

//Средняя оценка:
const calculateAverageGrade = (student) => {
  const sum = student.grades.reduce((acc, curr) => acc + curr, 0);
  return sum / student.grades.length;
};

const student = { grades: [4, 5, 3, 2, 5] };
console.log("Средняя оценка: " + calculateAverageGrade(student));

//Полное имя:
const getFullName = (person) => `${person.firstName} ${person.lastName}`;

const person = { firstName: "John", lastName: "Doe" };
console.log("Полное имя: " + getFullName(person));

//Калькулятор:
const calculator = {
  operand1: 5,
  operand2: 3,
  add: function () {
    return this.operand1 + this.operand2;
  },
  multiply: function () {
    return this.operand1 * this.operand2;
  },
};

console.log("Сумма: " + calculator.add());
console.log("Произведение: " + calculator.multiply());
